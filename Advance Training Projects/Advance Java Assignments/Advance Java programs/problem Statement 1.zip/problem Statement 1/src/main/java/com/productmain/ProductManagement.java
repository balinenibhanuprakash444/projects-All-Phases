package com.productmain;
import com.fpt.nhatnk.pms.ui.ProductConsole;

public class ProductManagement {

	 public static void main(String[] args) {
	        ProductConsole pc = new ProductConsole();
	        pc.start();
	    }
	    
	}